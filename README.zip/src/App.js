
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Page from "./Pages/Page";
import Products from "./Pages/Products";
import Blog from "./Pages/Blog";
import Contact from "./Pages/Contact";
import Home from "./Pages/Home";
import 'bootstrap/dist/css/bootstrap.css';
import Header from "./Header";
import Foot2 from "./Foot2";
function App() {
  return (
    <>
      <BrowserRouter>
      <div className='bg-header'>
      <Header /> 
      </div>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/page" element={<Page />}></Route>
          <Route path="/products" element={<Products />}></Route>
          <Route path="/blog" element={<Blog />}></Route>
          <Route path="/contact" element={<Contact />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
