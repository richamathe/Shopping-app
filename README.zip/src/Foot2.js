import { IoLocationSharp } from "react-icons/io5";
import { IoIosCall } from "react-icons/io";
import { MdMail } from "react-icons/md";
import { FaFacebook } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";
import { FaInstagramSquare } from "react-icons/fa";
import { FaPinterestSquare } from "react-icons/fa";

const Foot2 = () => {
  return (
    <>
      <div className="foot2-section">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
               <div className="sec-1">
                 <h4 className="reach-h">Reach at.. </h4>
                 <ul className="f-list">
                  <li><IoLocationSharp />Location</li><br></br>
                  <li><IoIosCall /> Call +11234567890</li><br></br>
                  <li> <MdMail />demo@gmail.com</li><br></br>
                 </ul>
                </div>
            </div>

            <div className="col-md-4">
                <div className="sec-1">
                    <h4 className="reach-h">Famms</h4>
                    <p>Necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with</p>
                    <div className="social-icon">
                    <FaFacebook className="f-icon"/>
                    <FaTwitter className="f-icon"/>
                    <FaLinkedin className="f-icon"/>
                    <FaInstagramSquare className="f-icon"/>
                    <FaPinterestSquare className="f-icon"/>
                    </div>
                </div>  
            </div>
          </div>
        </div>
        <hr className="line"></hr>
        <p className="foot2-p">  © 2024 All Rights Reserved By Free HTML Templates <br></br> Distributed By Richa mathe </p>
      </div>
    </>
  );
};
export default Foot2;
