import logo from "./images/logo.png";
const Footer = () => {
  return (
    <>
      <div className="foot-sec">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <img src={logo} width="210px" height="36px"></img>
              <div className="foot-info">
                <p><b>ADDRESS:</b> 28 White tower, Street Name New York City, USA </p>
                <p> <b>TELEPHONE:</b> +91 987 654 3210</p>
                <p><b>EMAIL:</b> yourmain@gmail.com</p>
              </div>
            </div>
            <div className="col-md-2">
                <div className="f-menu">
                    <h3 className="menu-h">MENU</h3>
                    <ul>
                       <li>Home</li>
                       <li>About</li>
                       <li>Services</li>
                       <li>Testimonial</li>
                       <li>Blog</li>
                       <li>Contact</li>

                    </ul>
                </div>
            </div>
            <div className="col-md-2">
            <div className="f-menu">
                    <h3 className="menu-h">ACCOUNT</h3>
                    <ul>
                       <li>Account</li>
                       <li>Checkout</li>
                       <li>Login</li>
                       <li>Register</li>
                       <li>Shopping</li>
                       <li>Widget</li>
                    </ul>
                </div>
            </div>
            <div className="col-md-4">
                <div className="f-news">
                    <h3 className="menu-h">NEWSLETTER</h3>
                    <p className="f-news-p">Subscribe by our newsletter and get update protidin.</p>
                    <form>  
                        <input type="email" placeholder="Enter your Mail" className="inp"></input>
                        <button className="prod-btn mt-0">Subscribe</button>
                    </form>
        
                </div>
            </div>
          </div>
        </div>
      </div>
      <div className="f-end">
        <p>© 2024 All Rights Reserved By <span>Free Html Templates</span> made by <span>Richa Mathe</span></p>
      </div>
    </>
  );
};
export default Footer;
