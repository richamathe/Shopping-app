import React from "react";
import { NavLink } from "react-router-dom";
import logo from "./images/logo.png";
import { MdLocalGroceryStore } from "react-icons/md";
import { IoMdSearch } from "react-icons/io";

const Header = () => {

  return (
    <>
      <div className="container">
        <div className="header-section">
        <div className="row">
          <div className="col-lg-6 px-10">
            <img src={logo} width="250px" height="43px"></img>
          </div>
          <div className="col-lg-6">
                <ul className="nav1">
                  <li> <NavLink to="/">Home</NavLink></li>
                  <li><NavLink to="/page">Pages</NavLink> </li>
                  <li><NavLink to="/products">Products</NavLink> </li>
                  <li><NavLink to="/blog">Blog</NavLink></li>
                 <li> <NavLink to="/contact">Contact</NavLink></li>
                 <li><MdLocalGroceryStore /></li>
                 <li><IoMdSearch /></li>
               </ul>
             </div>
        </div>
        </div>
      </div>
    </>
  );
};

export default Header;
