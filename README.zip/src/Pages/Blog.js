import React from "react";
import { NavLink } from "react-router-dom";
import Header from "../Header";
import { TbTruckDelivery } from "react-icons/tb";
import { TbCircleLetterQFilled } from "react-icons/tb";
import { FaFonticons } from "react-icons/fa";

const Blog = () => {
  return (
    <>
      {/* <Header /> */}
      <div className="why-layout">
        <div className="container">
          <h2 className="why-shop">Why Shop With Us</h2>
          <div className="why-card">
            <div className="row">
              <div className="col-md-4 ">
                <div className="why-box">
                  <div className="box-icon">
                    <TbTruckDelivery />
                  </div>
                  <div className="why-desc">
                    <h5>Fast Delivery</h5>
                    <p>variations of passages of Lorem Ipsum available</p>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="why-box">
                  <div className="box-icon">
                    <FaFonticons />
                  </div>
                  <div className="why-desc">
                    <h5>Free Shiping</h5>
                    <p>variations of passages of Lorem Ipsum available</p>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="why-box">
                  <div className="box-icon">
                    <TbCircleLetterQFilled />
                  </div>
                  <div className="why-desc">
                    <h5>Best Quality</h5>
                    <p>variations of passages of Lorem Ipsum available</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Blog;
