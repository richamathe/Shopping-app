import React from 'react'
import { NavLink } from "react-router-dom"
import Header from '../Header'
import Contact2 from './Contact2'

const Contact = () => {
  return (
   <>
        {/* <Header />   */}
        <Contact2 />
   </>
  )
}

export default Contact
