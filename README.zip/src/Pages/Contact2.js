import React from 'react'

const Contact2 = () => {
  return (
    <>
    <h3 className='cont-h'>Contact Us</h3>
     <div className='inp-box'>
      <input type='text' placeholder='Enter Your Full Name' className='inp1'></input><br></br>
      <input type='email' placeholder='Enter Your Email Address' className='inp1'></input><br></br>
      <input type='text' placeholder='Enter Subject' className='inp1'></input><br></br>
      <input type='textarea' placeholder='Enter Your Message' className='inp1'></input>
    </div>
    </>
   
  )
}

export default Contact2;
