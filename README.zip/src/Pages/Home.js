import React from "react";
import { NavLink } from "react-router-dom";
import girl from "./../images/girl.jpg";
import Header from "../Header";
import Blog from "./Blog";
import boy from "./../images/boy-img.png";
import Products from "./Products";
import Testimonial from "./Testimonial";
import Footer from "../Footer";
import Contact2 from "./Contact2";
import Foot2 from "../Foot2";

const Home = () => {
  return (
    <>
      {/* <Header /> */}
      <div className="container-fluid">
        <div className="row align-item-center">
          <div className="col-md-12">
            <div className="bg-img">
              <div className="slider-box">
                <h1 className="slider-h">
                  <span>Sale 20% Off</span>
                  <br></br>
                  On Everything
                </h1>
                <p className="slider-para">
                  Explicabo esse amet tempora quibusdam laudantium, laborum
                  eaque magnam fugiat hic? Esse dicta aliquid error repudiandae
                  earum suscipit fugiat molestias, veniam, vel architecto
                  veritatis delectus repellat modi impedit sequi.
                </p>
                <button className="slider-btn">Shop Now</button>
              </div>
            </div>
          </div>
        </div>

        <Blog />
        <div className="new-arrival-box">
          <div className="row">
<div className="col-6">
<img src={boy} className="" />
</div>
<div className="col-6">
<h2 className="new-arrival-h">#New Arrival</h2>
              <p className="new-arrival-p">
                Explicabo esse amet tempora quibusdam laudantium, laborum eaque
                magnam fugiat hic? Esse dicta aliquid error repudiandae earum
                suscipit fugiat molestias, veniam, vel architecto veritatis
                delectus repellat modi impedit sequi.
              </p>
              <button className="slider-btn">Shop Now</button>
</div>

          </div>
          {/* <div className="row">
            <div className="boy-box">
              <div className="col-lg-6">
                <img src={boy} width="100%" />
              </div>
            </div>

            <div className="col-lg-6">
              <h2 className="new-arrival-h">#New Arrival</h2>
              <p className="new-arrival-p">
                Explicabo esse amet tempora quibusdam laudantium, laborum eaque
                magnam fugiat hic? Esse dicta aliquid error repudiandae earum
                suscipit fugiat molestias, veniam, vel architecto veritatis
                delectus repellat modi impedit sequi.
              </p>
              <button className="slider-btn">Shop Now</button>
            </div>
          </div> */}
        </div>
        <Products />
        <div className="subscribe-section">
          <div className="row text-align-center">
            <div className="subs">
              <h3 className="subs-h">Subscribe To Get Discount Offers</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor
              </p>
              <form>
                <input
                  type="email"
                  placeholder="Enter Your Email"
                  className="inp-field"
                ></input>
                <br></br>
                <button className="subs-btn">Subscribe</button>
              </form>
            </div>
          </div>
        </div>
        <Testimonial />
        <Footer />
        <Foot2 />
      </div>
    </>
  );
};

export default Home;
