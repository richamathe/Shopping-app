import React from 'react'
import { NavLink } from "react-router-dom"
import Header from '../Header'

const Page = () => {
  return (
  <>
        {/* <Header />  */}
        <h1>This is page..</h1>
  </>
  )
}

export default Page
