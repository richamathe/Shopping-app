import React from "react";
import { NavLink } from "react-router-dom";
import Header from "../Header";
import p1 from "./../images/p1.png";
import p2 from "./../images/p2.png";
import p3 from "./../images/p3.png";
import p4 from "./../images/p4.png";
import p5 from "./../images/p5.png";
import p6 from "./../images/p6.png";
import p7 from "./../images/p7.png";
import p8 from "./../images/p8.png";
import p9 from "./../images/p9.png";
import p10 from "./../images/p10.png";
import p11 from "./../images/p11.png";
import p12 from "./../images/p12.png";
import Foot2 from "../Foot2";

const Products = () => {
  return (
    <>
      {/* <Header />  */}
      <div className="product-section">
        <div className="container">
          <h2 className="our-prod">Our <span>Products</span></h2>
          <div className="row">
            <div className="col-md-4">
              <div className="prod-1">
                <div className="prod-img">
                  <img src={p1} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p2} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$60</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p3} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Women's Dress</h5>
                  <h6>$80</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-4">
              <div className="prod-1">
                <div className="prod-img">
                  <img src={p4} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Women's Dress</h5>
                  <h6>$70</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p5} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Women's Dress</h5>
                  <h6>$80</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p6} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Women's Dress</h5>
                  <h6>$90</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-4">
              <div className="prod-1">
                <div className="prod-img">
                  <img src={p7}height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p8} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p9} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-4">
              <div className="prod-1">
                <div className="prod-img">
                  <img src={p10}height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p11} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Men's Shirt</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
            <div className="col-md-4">
            <div className="prod-1">
                <div className="prod-img">
                  <img src={p12} height="215px"></img>
                </div>
                <div className="prod-detail">
                  <h5>Women's Dress</h5>
                  <h6>$75</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="btn-box">
        <button className="prod-btn">View All Products</button>
        </div>
      </div>
    </>
    
  );
};

export default Products;
