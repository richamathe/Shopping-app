import Header from '../Header';
import client from './../images/client.jpg'
const Testimonial = ()=>{
    return(
      <>
      <div className="test-sec">
        <div className="container">
           <div className="row mt-5"  >
             <h2 className="test-h">Customer's Testimonial</h2>
             <div class="detail-box">
               <img src={client} className='test-img'></img>            
               <h5>Anna Trevor </h5>
               <h6>Customer</h6>
               <p className='test-p'> Dignissimos reprehenderit repellendus nobis error quibusdam? Atque animi sint unde quis reprehenderit, et, perspiciatis, debitis totam est deserunt eius officiis ipsum ducimus ad labore modi voluptatibus accusantium sapiente nam! Quaerat.</p>
             </div>
           </div>
        </div>
      </div>
      </>
    )
}
export default Testimonial;