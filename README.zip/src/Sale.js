import React from 'react'

const Sale = () => {
  return (
<>

</>
  )
}

export default Sale
